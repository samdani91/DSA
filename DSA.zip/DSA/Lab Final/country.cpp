#include<bits/stdc++.h>
using namespace std;

#define size 15
string country[size];
int graph[size][size];
bool visited[size];

void create_graph(int nodes,int edges);
void bfs(int start ,int nodes);

int main()
{

    int nodes,edges,start;
    string start_country;
    cin>>nodes>>edges;

    printf("Enter countries:");
    for(int i=1;i<=nodes;i++) cin>>country[i];
    create_graph(nodes,edges);

    printf("\nEnter starting country:");
    cin>>start_country;
    for(int i=1; i<=nodes; i++){
        if(start_country==country[i]){
        start=i;
        break;
        }
    }
    bfs(start,nodes);

    return 0;
}
void create_graph(int nodes,int edges){
    int u,v;
    string c1,c2;

    printf("\nEnter connections:");
    for(int i=1;i<=edges;i++){
        cin>>c1>>c2;

        for(int j=1;j<=nodes;j++){
            if(c1==country[j]) u=j;
            if(c2==country[j]) v=j;
        }

        graph[u][v]=1;
        graph[v][u]=1;

    }
}
void bfs(int start, int nodes) {
    int queue[size];
    int front = 0, rear = 0;

    
    visited[start] = 1;
    queue[rear++] = start;

    cout <<"You can travel from "<<country[start]<<" to: "<<endl;

    while(front != rear) {
        int current = queue[front++];

        if(current!=start)
        cout<<country[current]<<endl;

        for(int i = 1; i <= nodes; i++) {
            if(graph[current][i] == 1 && visited[i] == 0) {
                visited[i] = 1;
                queue[rear++] = i;
            }
        }
    }
}
